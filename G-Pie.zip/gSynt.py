#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import gModule1 as gm1
import pandas as pd
import numpy as np
import csv
    

# just something

def synthesize_Project(sOutputFilePath, shelves):
    sControlFileName = shelves.get("CONTROL")
    
    shelves = {}
    
    iStarPosition = 0
    #  points to the position of the starred facet, i.e. the facet requiring the next data line
    dSchema = None
    
    #  saves the current index value of the starred facet for comparison
       
    wFacets = {}
    # facets dictionary in main file
    
    lFacetOrder = []
    # facet order list in main file
    
    # generic schema in main file
    
    # read in control file
    gm1.rlReadControlFile (wFacets, lFacetOrder, sControlFileName, shelves)
    lAnchors = shelves.get('ANCHORS')
    lVariances = shelves.get('VARIANCES')
    iStarPosition = int(shelves.get('NEWLINE'))
    
    lAlphas = gm1.rlAlphas(wFacets, lFacetOrder)
    
    iComponents = len(lAlphas) - 1
    
    dSchema = gm1.rdSchema(wFacets, lFacetOrder, 0, None, False).object()
    
    lRandomSet = gm1.lGetRandomSets(wFacets, dSchema, lAlphas, lVariances, shelves)
    lVal = lRandomSet[iComponents]
    df = dSchema.drop(columns = ['X'])
    df['X'] = lVal
    
    lVal = lRandomSet[iComponents]
    df = dSchema.drop(columns = ['X'])
    df['X'] = lVal
    for i in range(len(lAlphas) -1):
        df = gm1.dfSynthesize(dSchema, lRandomSet, lAlphas, df, i)
    
    cPos = lFacetOrder[iStarPosition]
    iMaxCount = 0
    iMinCount = 0
    line = [0]
    iLineCounter = 0
    iLastLine = 0
    
    with open( sOutputFilePath, 'w', newline='') as csvFile:
        dataWriter = csv.writer(csvFile, delimiter = ',')
        lAnchors = lAnchors[1:]
        for index, row in df.iterrows():
            iPIndex = int(row[cPos])
            fScore = row['X']
            iScore = int(fScore + float(lAnchors[1]))
            if iScore < int(lAnchors[0]):
                iMinCount += 1
                iScore = int(lAnchors[0])
            if iScore > int(lAnchors[2]):
                iMaxCount += 1
                iScore = int(lAnchors[2])
            if iPIndex != iLastLine:           # end of line
                dataWriter.writerow(line)
                iLineCounter += 1
                iLastLine = iPIndex
                line = [iLineCounter]
            line.append(iScore)
        dataWriter.writerow(line)
    

