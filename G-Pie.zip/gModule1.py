#!/usr/bin/env python
# coding: utf-8

# ### Module for G-Pie project in gp2

import linecache as lc
import pandas as pd
import numpy as np
import statistics as st
pd.options.mode.copy_on_write = True


# ### Class Facet 
# The 'Facet' class is the central element of G-Pie. Much of it is pretty self evident. But the mission-critical method of facet is **'Facet.increment'**. It is responsible for linking serial scores with changes of the facet index. The least little error in the increment method will endanger the reliability of the entire analysis.

# In[ ]:


class rcFacet:
    def __init__(self, sName, zLabel):
        # Constants -----------------------------------------------------------
            # label: a character, designating the facet
        self.label = zLabel 
            # name: a string describing the facet
        self.name = sName
            # type: designates the type of facet - 'd' (Differentiation), 'g' (Generalization), and 's' (Stratification)
            #    see manual -> 3 Brennan Rules
        self.type = 'g'
            # weight: factor in averaging denominator for variance of mean
        self.weight = 1.0
            # newLine: a Boolean indicating if the data file starts a new line when this particular facet index changes
        self.newLine = False
            # effect: a string depicting the nesting pattern for this facet
        self.effect = ''
            # sizes: a list of the sample sizes for this facet
        self.sizes = []
            # nestor: a character pointing to the facet in which the current facet is nested
        self.nestor = ''
            # next: a character pointing to the next facet in the incementation order
        self.next = 'x'
            # isNestor: a boolean indicating, wether this facet is nesting child facets
        self.isNestor = False
            # list of nestees
        self.lNestees = []
            # depth of nesting
        self.iDepth = 0
        
        #  other Variables -----------------------------------------------------------
            # index: an integer containing the current index value for that facet
        self.index = 0
            # ceiling: an integer current ceiling value for the index
        self.ceiling = 0
    def setDifferentiation (self, bD):
        if bD:
            self.type = 'd'
    def setStratification (self, bS):
        if bS:
            self.type = 's'
            self.weight = 1.0
    def setSizes(self, lSizes):
        for i in lSizes:
            self.sizes.append(i)
            
    def setDepth(self, iD):
        self.iDepth = iD
    def setWeight(self):
        #print(self.label)
        if self.type == 'd':
            self.weight = 1
            #print ('Facet ', self.label, ' type ', self.type, ' has weight ', self.weight)
        elif self.type == 's':
            self.weight = 1
            #print ('Facet ', self.label, ' type ', self.type, ' has weight ', self.weight)
        else:
            if len(self.effect) > 3:
                self.weight = st.harmonic_mean(self.sizes)
                #print ('Facet ', self.label, ' type ', self.type, ' has weight ', self.weight)
            else:
                self.weight = st.mean(self.sizes)
                #print ('Facet ', self.label, ' type ', self.type, ' has weight ', self.weight)
    def getSizes(self):
        a = []
        for i in self.sizes:
            a.append(i)
        return a 
    def hasNestor(self):
        if self.nestor == 'xx':
            return False
        else:
            return True
    def addNestee(self, cNestee):
        self.lNestees.append(cNestee)        
    def increment(self, wFacets):
        if self.index < self.ceiling - 1:
           self.index += 1
           return self.label
        else:
            # ceiling reached
            self.index = 0
            lNext = self.next
            if lNext == 'yy':
                # end of iteration
                return 'yy'
            else:
                # iteration proceeds to next level
                iLast = 'zz'
                fNext = wFacets.get(self.next)
                lSizes = self.sizes
                iLast = fNext.increment(wFacets)
                if iLast == 'yy':
                    return 'yy'
                if self.nestor == 'xx':
                    #print('xx')
                    return 'xx'
                if self.nestor == 'yy':
                    return 'yy'
                fNestor = wFacets.get(self.nestor)
                self.ceiling = lSizes[fNestor.index]
                return iLast
    def print(self):
        print('lTarget = ', self.label, '; index = ', str(self.index), '; Nestor = ', self.nestor, '; Next = ', self.next, '; Sizes = ',
              self.sizes, '; Type = ', self.type, '; Weight = ', self.weight, '; Nestees: ', self.lNestees, '; Depth: ', self.iDepth)


# ### Read Control File
# The control file informs G-Pie of the design of the particular analysis. It is equivalent to Brennan's set of 'Control cards' in urGENOVA. The 'rlControlFile' function reads in the text file, performs a simple lexical scan, and stores the contained information in the appropriate variables of G-Pie

# In[ ]:


def rlReadControlFile (wFacets, lFacetOrder, sControlFileName, shelves):
    # wFacet: a python dictionary of all facet objects with single character keys
    # lFacetOrder: a python list of single characters documenting the order, in which facet indices have to be incremented, when   interpreting the data file
    # sType = 'Ana' - read analysis control file
    #       = 'Syn' - read synthesize control file
    facetCounter = 0
    # lCarry = 'yy'
    with open(sControlFileName) as file:
        lines = [line.rstrip() for line in file]
        for  sLine in lines:
            lWords = sLine.split()
            match lWords[0]:
                case "COMMENT*":
                    addFacet (wFacets, lWords)
                case "EFFECT":
                    rlAddEffect (wFacets, lFacetOrder, lWords, shelves)
                    facetCounter += 1
                case _:
                    # Default
                    shelves.update({lWords[0]:lWords})
    file.close()
    # now adjust the first facet in the sequence
    lf = lFacetOrder[0]
    f = wFacets[lf]
    f.nestor = 'yy'


# ### Method, add Facet to Facets array  

# In[ ]:


def addFacet (wFacets, lWords):
    bIs_D = (len(wFacets) == 0)
    lFacetWords = [word for word in lWords if word not in ['COMMENT*']]
    zLabel = lFacetWords[1].replace('(','').replace(')','')
    sName = lFacetWords[0]
    f = rcFacet(sName, zLabel)
    if bIs_D:   # is facet of differentiation
        f.setDifferentiation(True)
    wFacets.update({zLabel:f})    


# ### Method to add effects to facets 

# In[ ]:


def rlAddEffect (wFacets, lFacetOrder, lWords, shelves):
    vEffectWords = [word for word in lWords if word not in ['EFFECT']]
    iPointer = 0
    #  extract effect string
    sEffect = vEffectWords[iPointer].split()[0]
    # handle 'newLine'
    bNewLine = False
    #  identify  facet corresponding to the line in the score file 
    if '*' in sEffect:
        iPointer += 1
        sEffect = vEffectWords[iPointer].split()[0]
        shelves.update({'NEWLINE':len(lFacetOrder)})
    #  identify the facet to which this effect belongs
    res = list(sEffect)
    lTarget = res[0]
    f = wFacets.get(lTarget)       
    iPointer += 1
    lSizes = riArray(vEffectWords[iPointer::])
    f.effect = sEffect
    #  break effect into nestings
    vF = sEffect.split(':')
    if (len(vF) < 2):
        f.nestor = 'xx'     # this facet is crossed
    else:
        cfn = vF[1]
        f.nestor = cfn      # this facet is nested in facet cfn
        fn = wFacets.get(cfn)
        fn.isNestor = True
        fn.addNestee(lTarget)
        f.setDepth(fn.iDepth + 1)
        if ((f.type == 'd') or (f.type == 's')):
            fn.setStratification(True)
        wFacets.update({cfn:fn})
    f.setSizes(lSizes)
    if f.type == 'd':    # facet of differentiation
        nSize = 0
        for i in lSizes:
            nSize += i
        shelves.update({'DSIZE':nSize})
        
    f.setWeight()
    f.ceiling = lSizes[0]
    l = len(lFacetOrder)
    if l == 0:
        f.next = 'yy'
    else:
        sNext = lFacetOrder[l-1]
        f.next = sNext
    f.newLine = bNewLine
    lFacetOrder.append(lTarget)
    wFacets.update({lTarget:f})


# ### Incorporate data file format information 

# In[ ]:


def rlAddFormat(lWords):
    lFacetWords = [word for word in lWords if word not in ['COMMENT*']]
    skip2 = lFacetWords[1]
    width2 = lFacetWords[2]
    return [skip2, width2]


# ### Set up list of alphas

# In[ ]:


def rlAlphas (wFacets, lFacetOrder):
    #print (lFacetOrder)
    i = len(lFacetOrder)
    ex = 2**i
    Nestors = []
    for j in range(i):
        Nestors.append(wFacets.get(lFacetOrder[j]).nestor)
    alphas = []
    # create alpha individuals
    for j in range(ex):
        sMask = list(str(bin(j + 2**(i+1)))[-i:])
        alpha = ''
        for k in range(i):
            if ((sMask[k] == '1') and ((Nestors[k] in alpha) or (Nestors[k] == 'yy' or Nestors[k] == 'xx'))):
                alpha += lFacetOrder[k]
            if (alpha and (alpha not in alphas)):
                #print('sAlpha = ', alpha)
                alphas.append(alpha)
    # now sort them according to FacetOrder
    # sort alphas in FacetOrder
    length = len(lFacetOrder)
    weights = {}
    for i in range(length):
        weights[lFacetOrder[i]] = (0.05**(length - i))
    sorter = {}
    for alpha in alphas:
        p = 0
        for c in alpha:
            p += weights[c]
        sorter[p] = alpha
    alphas = []
    for v in sorted(sorter):
        alphas.append(sorter[v])
    return alphas


# ### Read data with its structure 

# In[ ]:


class rcX:
    def __init__(self, sDataFileName, delimiter, StarPosition, skip):
        self.FileName = sDataFileName
        self.delimiter = delimiter
        self.StarPosition = StarPosition
        self.NumberofLines = 0
        self.oldValue = ''
        self.line = 0
        self.skip = int(skip)
        self.position = int(skip)
        self.sItem = None
        self.count = 0        
        self.scores = lc.getline(self.FileName, self.line).split(self.delimiter)
    def getValue(self, indices):
        self.count += 1
        newValue = str(indices[self.StarPosition])
        if self.oldValue != newValue:
            self.oldValue = newValue
            self.line += 1
            self.position = self.skip
            lc.clearcache()
            try:
                self.scores = lc.getline(self.FileName, self.line).split(self.delimiter)
            except:
                print('ERROR! No more data.')
                print('====================')
                print('Filename = ', self.FileName)
                print('LineCount = ', self.line)
                print('Position = ', self.position)
                print('Delimiter = ', self.delimiter)
                print ('Error after ', self.count, ' counts')
                print ('Indices at failure were: ', indices)
        self.sItem = self.scores[self.position]
        if (self.sItem == ''):
            print('ERROR!  Data line too short')
            print('======')
            fItem = None
        else:
            try:
                fItem = float(self.sItem)
            except:
                print('no float', self.sItem)
            value = [fItem]
        for element in indices:
            value.append(element)
        self.position += 1
        return value
    def final(self):
        lc.clearcache();


# ### Establishes the 'Schema' data frame

# In[ ]:


class rdSchema:
    def __init__(self, wFacets, lFacetOrder, StarPosition, Data, bMu): 
        first = lFacetOrder[-1]
        cols = ['X']
        for item in lFacetOrder:
            cols.append(item)
        counter = 0
        self.Data = Data
        self.schema = pd.DataFrame(columns = cols)
        last = lFacetOrder[-1]
        while last != 'yy':
            counter += 1
            vIndices = []
            for l in lFacetOrder:
                f = wFacets.get(l)
                #item = str(f.index) + '|'
                item = str(f.index)
                vIndices.append(item)
            f = wFacets.get(first)
            last = f.increment(wFacets)           # increments facets in recursive schema build
            if self.Data is None:
                self.schema.loc[counter] = ["0.0"] + vIndices
            else:
                x = self.Data.getValue(vIndices)
                if (x[0] != None):
                    score = float(x[0])
                    x.pop(0)
                    x.insert(0, score)
                    self.schema.loc[counter] = x
        if self.Data is not None:
            if bMu:
                mu = self.schema['X'].mean()
                self.schema['X'] -= mu
            self.Data.final()
    def object(self):
        return self.schema
    


# ### Utility to convert numeric string array to integer list

# In[ ]:


def riArray (strArray):
    intList = []
    for s in strArray:
        intList.append(int(s))
    return intList


# ### Method to calculate ANOVA ET($\alpha$); Brennan: "Generalizability Theory", 2001; equation (7.1), page 218 

# In[ ]:


def reET(dSchema, lAlphas, N, mu, shelves):
    lT = []
    lSampleSizes = []
    for sAlpha in lAlphas:
        if sAlpha != 'mu':
            df = dSchema.copy(deep=True).groupby(list(sAlpha)).agg(Xsum = ('X', 'sum'), count = ('X', 'count')).reset_index()
            df['sum2'] = df['Xsum'].pow(2)/df['count']
            eT = df['sum2'].sum()
            iCount = df['sum2'].count()
            lSampleSizes.append(int(iCount))
        else:
            eT= N * mu**2
        lT.append(eT)
    shelves.update({'Sample Sizes':lSampleSizes})
    return lT


# ### Format $\boldsymbol{\alpha}$ 

# In[ ]:


def rsFormatAlpha(wFacets, sAlpha):
    form = ''
    for c in sAlpha:
        fa = wFacets.get(c)
        if len(fa.nestor) == 1:
            form += ':'
        form += c
    if (form[-1] == ':'):
        form = form[:-1]
    form = form[::-1]
    return form           

def rsEpsilon(sAlpha, sBeta):
    sResult = ''
    for z in list(sAlpha):
        if ((z not in sBeta) and (z not in sResult)):
            sResult += z
    return sResult

def eaK(dSchema, lAlphas, N, mu):
    T = N*mu**2
    EK = []
    for sBeta in lAlphas:
        lLine = []
        if sBeta != 'mu':
            for sAlpha in lAlphas:
                if sAlpha != 'mu':
                    sEpsilon = rsEpsilon(sAlpha, sBeta)
                    sDelta = sBeta + sEpsilon
                    df = dSchema.copy(deep=True).groupby(list(sDelta)).agg(ng = ('X', 'count')).reset_index()
                    df['ng2'] = df['ng'].pow(2)
                    df = df.groupby(list(sBeta)).agg(sng2 = ('ng2', 'sum'), sng = ('ng', 'sum')).reset_index()
                    df['weighted'] = df['sng2']/df['sng']
                    Kab = df['weighted'].sum()
                    lLine.append(Kab)
                else:
                    lLine.append(N)
        else:
            for sAlpha in lAlphas:
                if sAlpha != 'mu':
                    df = dSchema.copy(deep=True).groupby(list(sAlpha))['X'].count().reset_index()
                    Kamu = df['X'].pow(2).sum()/N
                    lLine.append(Kamu)
                else:
                    lLine.append(N)
        EK.append( lLine )
    #shelves.update({'SampleSizes':lSampleSizes})
    return EK


# ### Calculate Random List Set

# In[ ]:


def lGetRandomSets(wFacets, dSchema, lAlphas, lVariances, shelves):
    import math
    lRandomSet = []
    lSampleSizes = []
    eThrowAway = np.random.normal(0.0, 1.0,1000)
    eThrowAway = None
    lVariances = lVariances[1:]
    for i in range(len(lAlphas)):
        df = dSchema.copy(deep=True).groupby(list(lAlphas[i]))['X'].count().reset_index()
        iCountAlpha = df['X'].count()
        lSampleSizes.append(iCountAlpha)
        vi = float(lVariances[i])
        eStdDev = math.sqrt(vi)
        eMean = 0.0
        raw = np.random.normal(loc = eMean, scale = eStdDev, size = iCountAlpha)
        eMean = raw.mean()
        eVar = raw.var()
        if eVar != 0.0:
            eCor = math.sqrt(float(lVariances[i])/eVar)
            normalized = (raw - eMean) * eCor
        else:
            normalized = raw
        eMean = float(normalized.mean())
        eVar = float(normalized.var())
        iCount = len(normalized)
        lRandomSet.append(normalized)
    shelves.update({'SampleSizes':lSampleSizes})
    return lRandomSet
    

    


# ### Apply Facet to Synthetic X

# In[ ]:


def dfSynthesize(dSchema, SuperArray, lAlphas, df, i):
    sAlpha = lAlphas[i]
    df = df.set_index(list(sAlpha))
    dfSource = dSchema.copy(deep=True).groupby(list(sAlpha)).count().reset_index()
    dfSource['X1'] = SuperArray[i]
    dfSource = dfSource.set_index(list(sAlpha))
    lFacets = list(lAlphas[-1])
    for c in sAlpha:
        lFacets.remove(c)
    lFacets.append('X')
    dfSource = dfSource.drop(columns = lFacets)
    fdResult = df.join(dfSource)
    fdResult['X2'] = fdResult['X'] + fdResult['X1']
    fdResult = fdResult.reset_index()
    fdResult = fdResult.drop(columns = ['X', 'X1'])
    fdResult = fdResult.rename(columns={'X2': 'X'})
    return fdResult


# ## Output Management

# In[ ]:


def output(file, line):
    if file is None:
        print (line)
    else:
        sBuffer = ''
        for s in line:
            sBuffer += s
        file.write(sBuffer + '\n')

