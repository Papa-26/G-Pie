#!/usr/bin/env python
# coding: utf-8

# # **G-Ana**, Summary
# G-Pie is a Python module that performs the actual **Generalizability Analysis** of assessment data, and other similar experimental data within the context of G-Pie.
# 
# (DOI
# https://doi.org/10.1007/BF02310555)
# 

import gModule1 as gm1
import pandas as pd
import numpy as np

lOutput = dict()
# list of lines (str) serving as a text container to return analysis results back to G-Pie

iSkip = 1
#  number of items in each data line that have to be skipped, before actual score data are listed

iWidth = 0
#  if 0, data separators are used, otherwise the width of fixed item fields in the file

iStarPosition = 0
#  points to the position of the starred facet, i.e. the facet requiring the next data line

iCurrentStar = 0
#  saves the current index value of the starred facet for comparison

zDelimiter = ','
#  data file delimiter

wFacets = dict()
# facets dictionary in main file

lFacetOrder = []
# facet order list in main file

#  python dictionary to shelve additional input lists

dBaseSchema = None
# generic schema in main file

def output(oName, thing):
    lOutput.update({oName:thing})

def getTypes(sAlpha):
    sFacets = sAlpha.replace(':', '')
    types = ''
    for c in sFacets:
        f = wFacets.get(c)
        t = f.type
        if (t not in types):
            types += t
    return types

def printFacets():
    for sF in lFacetOrder:
        f = wFacets.get(sF)
        f.print()
    
def analyze(shelves):
    #  working files from shelves argument
    sControlFileName = shelves.get("CONTROL")    
    sDataFileName = shelves.get("DATA")
    wSettings = shelves.get('SETTINGS')
    #  shelves brought in as argument
    
    #-------------------------------------------------------------------------------------------------
    # read in control file
    gm1.rlReadControlFile (wFacets, lFacetOrder, sControlFileName, shelves)
    iStarPosition = int(shelves.get('NEWLINE'))
    #  printFacets()
    # establish the alpha list 'alphas'
    lAlphas = gm1.rlAlphas(wFacets, lFacetOrder)

    lTypes = []
    for sAlpha in lAlphas:
        lTypes.append(getTypes(sAlpha))

    lTypes.append('none')
    output('TYPES', lTypes)
    
    # read in data file
    dData = gm1.rcX(sDataFileName, zDelimiter, iStarPosition, iSkip)
    
    # set up 'Schema', the comprehensive project data frame
    dSchema = gm1.rdSchema(wFacets, lFacetOrder, iStarPosition, dData, wSettings.get('NORMALIZE')).object()
    output('SCHEMA', dSchema)
    
    sHeader = '           '
    for s in shelves.get('GSTUDY'):
        sHeader += ' ' + s
    output('HEADER', sHeader)
    
    N = dSchema.copy(deep = True)['X'].count()
    mu = dSchema.copy(deep = True)['X'].mean()
    
    lAlphas.append('mu')    
    
    aT = np.array(gm1.reET(dSchema, lAlphas, N, mu, shelves))
    output('ET', aT.round(decimals = 4))
    
    aK = np.array(gm1.eaK(dSchema, lAlphas, N, mu))
    output('CMATRIX', aK.round(decimals = 4))

    lis = aK.tolist()
    L = len(lis)
    alphas  = []
    for sAlpha in lAlphas:
        if sAlpha == 'mu':
            alphas.append('μ')
        else:
            alphas.append(gm1.rsFormatAlpha(wFacets, sAlpha))

    for i in range(L):
        row = lis[i]
        if i == L - 1:
            line = 'μ'
        else:
            line = gm1.rsFormatAlpha(wFacets, lAlphas[i])
        for j in range(L):
            sItem = str(round(row[j], 1))
            if sItem[-2:] == '.0':
                sItem = sItem[:-2] + '  '
            line += sItem.rjust(10)
    lTA = aT.round(decimals = 4)

    lSigmas = np.linalg.solve(aK, aT)
    lsig = lSigmas.round(decimals=4)
    l = len(lAlphas) - 1
    lSS = shelves.get('Sample Sizes')
    lSS.append(1) # to adjust array length
    
    dict = {'Effect': alphas, 'Sizes': lSS, 'T(α)': lTA}
    df = pd.DataFrame(dict)
    output('RESULTS', df)
    output('SIGMAS', lsig)
    return lOutput


# In[ ]:




