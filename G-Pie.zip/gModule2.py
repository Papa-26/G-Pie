#!/usr/bin/env python
# coding: utf-8

## gModule2 ##
## as gm2 handles graphical user interface details

import gAna as ga
import tkinter as tk
import tkinter.font
import numpy as np
import pandas as pd
import time
from tabulate import tabulate
from sys import platform

def get_super(x): 
    normal = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-=()"
    super_s = "ᴬᴮᶜᴰᴱᶠᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾQᴿˢᵀᵁⱽᵂˣʸᶻᵃᵇᶜᵈᵉᶠᵍʰᶦʲᵏˡᵐⁿᵒᵖ۹ʳˢᵗᵘᵛʷˣʸᶻ⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾"
    res = x.maketrans(''.join(normal), ''.join(super_s)) 
    return x.translate(res) 

# - - adjust function for denominator
def adjustSize(size, type, factor):
    if type == 'none':
        return 0
    elif 'd' in type:
        return size/factor
    else:
        return size
# - - calculate Variance of Mean Component (VMC) 
def setVMC(sigma2, denom):
    if sigma2 < 0:
        return 0.0
    elif denom != 0:
        return round(sigma2/denom, 4)
    else:
        return 0
        
# - - logic directing normalized variance to tau, delta and Delta respectively

def setTarget(sType):
    sType = sType.replace('s', '')
    d = ''
    if sType == 'd':
        d = 'τ'
    elif sType == 'dg':
        d = 'Δ, δ'
    elif sType == 'g':
        d = 'Δ'
    return d

# - - calculate the value for a given object of measurement (tau, delta, or Delta)
def BrennanRules(target, vom, objM):
    if objM in target:
        return vom
    else:
        return 0.0

def displayItem(text, item, tags):
    iBefore = text.index(tk.INSERT)
    text.insert(tk.END, item)
    iAfter = text.index(tk.INSERT)
    for tag in tags:
        text.tag_add(tag,iBefore, iAfter)

# - - the actual preparation of the GA table
def analyze_Project(text, shelves):
    label = 'σ' + get_super('2') +'(α)'
    erLabel = 'Eρ' + get_super('2')
    text.tag_configure("center",justify='center')
    text.tag_configure("left",justify='left')
        
    if platform == 'darwin' or platform == 'os*':
        table_font = tkinter.font.Font(family = "Menlo" , size = 12)
    else:
        table_font = tkinter.font.Font(family = "Consolas" , size = 12)
    bold_font = tkinter.font.Font(font = "Georgia 14 bold")
    regular_font = tkinter.font.Font(font = "Georgia 12")
    text.tag_configure("mono",font=table_font)
    text.tag_configure("bold", font = bold_font)
    text.tag_configure("regular", font = regular_font)
    text.tag_configure("margin", lmargin1=20, lmargin2=20, lmargincolor=text.cget("background"))
    
    # - - perform statisticall analyisis with results in list 'lResults'
    started = time.time()
    lResults = ga.analyze(shelves)
    # - - display title
    dSize = shelves.get('DSIZE')
    text.insert(tk.END, ' -  \n')

    # - - Show header
    displayItem(text, lResults.get('HEADER') + '\n', ['center', 'bold'])
    # - - Show dataframe title
    displayItem(text, '\n\nDataFrame Containing the Whole Project Design\n\n', ['left', 'regular'])
    # - - Show dataframe
    displayItem(text, lResults.get('SCHEMA'), ['center', 'mono'])
    # - - analysis results, title 
    displayItem(text, '\n\nCalculated arrays\n', ['left', 'regular'])
    # - - analysis results, data
    df1 = lResults.get('RESULTS')
    lSigmas = lResults.get('SIGMAS')
    table1 = tabulate(df1, headers = ['α', 'GLM Sizes', 'T(α)', label], tablefmt="fancy_outline", showindex="never")
    displayItem(text, table1, ['center', 'mono'])
    # - - Coefficient matrix, title
    displayItem(text, "\n\n Henderson's Coefficient Matrix --> k[" + label + ", 𝗘T(β)]\n\n", ['left', 'regular'])
    # - - Coefficient matrix, data
    df2 = np.round(lResults.get('CMATRIX'), 1)
    table2 = tabulate(df2,tablefmt="plain")
    displayItem(text, table2, ['center', 'mono'])
    # - - Calculating Generalizability Coefficients from Variance Components, title
    displayItem(text, "\n\nAfter Solving Henderson's System of Linear Equations\n\n", ['left', 'regular'])
    # - - Coefficient logic, calculation
    s1 = df1['α']
    s2 = df1['Sizes']
    s3 = lSigmas
    s4 = pd.Series(lResults.get('TYPES'))
    frame = {'α':s1, 'Denom':s2, label:s3, 'Type':s4}
    df3 = pd.DataFrame(frame)
    df3['Denom'] = df3.apply(lambda x: adjustSize(x['Denom'], x['Type'], dSize), axis = 1)
    df3 = df3.copy(deep = True)
    # - - Coefficient logic, display
    df3['var. of mean'] = df3.apply(lambda x: setVMC(x[label], x['Denom']), axis = 1)
    table3 = tabulate(df3, headers="keys", tablefmt="fancy_outline", showindex="never")
    displayItem(text, table3, ['center', 'mono'])
    # - - Brennan's rules, title
    displayItem(text, "\n\nApplying Brennan's rules to calculate the Generalizability Coefficients\n\n", ['left', 'regular'])
    # - - Brennan's rules, calculations
    df3['Target'] = df3['Type']
    df3['Target'] = df3.apply(lambda x: setTarget(x['Type']), axis =1)
    table3 = tabulate(df3, headers="keys", tablefmt="fancy_outline", showindex="never")
    displayItem(text, table3, ['center', 'mono'])
    # - - final coefficients
    tau = df3[df3['Target'].str.contains('τ')]['var. of mean'].sum()
    delta = df3[df3['Target'].str.contains('δ')]['var. of mean'].sum()
    Delta = df3[df3['Target'].str.contains('Δ')]['var. of mean'].sum()
    Erho2 =tau/(tau + delta)
    Phi = tau/(tau + Delta)
    txt1 = 'τ = ' + str(round(tau, 4)) + ', δ = ' + str(round(delta, 4)) + ', Δ = ' + str(round(Delta, 4)) + '\n\n'
    txt2 = erLabel + ' = ' + str(round(Erho2, 4)) + '\n\n'
    txt3 = 'Φ    = ' + str(round(Phi, 4)) + '\n\n'
    iBefore = text.index(tk.INSERT)
    text.insert(tk.END, "\n\nFinal Results of Analysis\n\n")
    text.insert(tk.END, txt1)
    text.insert(tk.END, txt2)
    text.insert(tk.END, txt3)
    iAfter = text.index(tk.INSERT)
    text.tag_add("center", iBefore, iAfter)
    text.tag_add("bold", iBefore, iAfter)
    # - - Processing time 
    iBefore = iAfter
    completed = time.time()
    sFinal = '\n\n    Total Processing Time: ' + str(round((completed - started), 3)) + ' sec'
    text.insert(tk.END, sFinal)
    iAfter = text.index(tk.INSERT)
    text.tag_add("left", iBefore, iAfter)



