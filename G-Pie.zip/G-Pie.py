import tkinter as tk
import os
import pickle as pk
from tkinter import TRUE, W, filedialog
import gAna as ga
import gModule2 as gm2
import gSynt as synt
from tkinter import BOTH, LEFT, RIGHT, TOP, Y

root = tk.Tk()
root.config(bg='grey85')
root.title('Generalizability Analysis')
root.geometry('800x600')

bControl = False
bData = False
sInitialDataDirectory = ''
normalizeVariable = tk.IntVar()
settingsFilePath = 'settings.pkl'
wSettings = dict()


#  Load settings
shelves = dict()

def sLastPath(sPath):
    lPath = sPath.split('/')
    n = len(lPath)
    sPath = lPath[n-2] + '/' + lPath[n-1]
    return sPath

#  handles GUI 'read control file'
def open_ControlFile_dialog():
    global bControl, sInitialDataDirectory
    file_path = filedialog.askopenfilename(initialdir=sInitialDataDirectory, title="Select a Control File", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
    if file_path:
        sPath = sLastPath(file_path)
        if (sPath.split('.')[-1] == 'txt'):
            shelves.update({'CONTROL':str(file_path)})
            sDir = os.path.dirname(file_path)
            sInitialDataDirectory = sDir
            wSettings.update({'DATADIR': sInitialDataDirectory})
            #print(wSettings)
            cFile_Variable.set(sPath)
            bControl = True
    else:
        message_Variable.set('File type is not correct (.csv)!')
        
def save_to_file():
    file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
    if file_path:
        try:
            with open(file_path, 'w') as file:
                text_content = text.get("1.0", "end-1c")
                file.write(text_content)
            message_label.config(text=f"File saved: {file_path}")
        except Exception as e:
            message_label.config(text=f"Error saving file: {str(e)}")
    
#  handles GUI 'read data file'
def open_DataFile_dialog():
    global bData, sInitialDataDirectory
    file_path = filedialog.askopenfilename(initialdir=sInitialDataDirectory, title="Select a Data File", filetypes=[("csv. files", "*.csv"), ("All files", "*.*")])
    if file_path:
        sPath = sLastPath(file_path)
        if (sPath.split('.')[-1] == 'csv'):
            shelves.update({'DATA':str(file_path)})
            sDir = os.path.dirname(file_path)
            sInitialDataDirectory = sDir
            dFile_Variable.set(sPath)
            bData = True
        else:
            message_Variable.set('File type is not correct (.txt).')

#  immediate command to performG-Abnalysis, being passed on
def analyze_Project():
    global message_label
    text = tk.Text(text_frame, padx = 5, pady = 1, width = 1, height = 1, wrap="word", undo=True, font=("Georgia", "12"))
    text.pack(side = LEFT, fill = BOTH, expand=1)
    ys = tk.Scrollbar(text_frame, orient = 'vertical', width = 25, command = text.yview)
    ys.pack(side = RIGHT)
    text['yscrollcommand'] = ys.set
    sMessage = 'Both files are present, now analyzing!'
    if bControl and bData:
        message_label.configure(text=sMessage)
        root.update()
        gm2.analyze_Project(text, shelves)
        message_label.configure(text='The analysis is complete.')
    else:
        message_Variable.set('Inputs are incorrect.')

#  command to synthesize data
def synthesize_Project():
    if bControl:
        sMessage = 'Control file present, please enter location for synthetic score file.'
        message_label.configure(text=sMessage)
        root.update()
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", title="Create or select a result file:", filetypes=[(".csv files", "*.csv"), ("All files", "*.*")])        
        if file_path:
            synt.synthesize_Project(file_path, shelves)
            message_label.configure(text='The synthesis is complete.')
            root.update()
        else:
            message_Variable.set('Please create a result file first')  

#  command to display any file
def showFile():
    file_path = filedialog.askopenfilename(initialdir=sInitialDataDirectory, title="Select File", filetypes=[("csv. files", "**.*"), ("All files", "*.*")]) 
    if file_path:
        file = open(file_path, 'r')
        for line in file.read():
            text.insert('END', line + '\n')
        file.close()
    
def clear_All():
    global shelves
    text.delete("1.0", tk.END)
    cFile_Variable.set('')
    dFile_Variable.set('')
    shelves = {}
    os._exit

def save_settings():
    global wSettings
    with open('settings.pkl', 'wb') as fp:
        pk.dump(wSettings, fp)
    fp.close()

#load_settings()
def load_settings():
    global wSettings, normalizeVariable, shelves, sInitialDataDirectory
    if not os.path.exists(settingsFilePath):
        sInitialDataDirectory = os.getcwd()
        wSettings.update({'DATADIR':sInitialDataDirectory},{'NORMALIZE':False})
    else:
        with open(settingsFilePath, 'rb') as fp:
            wSettings = pk.load(fp)
            shelves.update({'SETTINGS':wSettings})
            #print('Loaded Settings ', wSettings)
            sInitialDataDirectory = wSettings.get('DATADIR')
            normalizeVariable.set(wSettings.get('NORMALIZE'))

def normalizeChange():
    global shelves, normalizeVariable, wSettings
    iState = normalizeVariable.get()
    #print('iState = ', iState)
    wSettings.update({'NORMALIZE':iState})       
    shelves.update({'SETTINGS':wSettings})
    save_settings()

# load settings
load_settings()
my_menu = tk.Menu(root)
root.config(menu=my_menu)

# create file menu
file_menu = tk.Menu(my_menu)
my_menu.add_cascade(label="             File             ", menu=file_menu)
file_menu.add_command(label = "  Read Control File", command=open_ControlFile_dialog)
file_menu.add_command(label = "  Read Data File", command=open_DataFile_dialog)
file_menu.add_command(label = "  Save Result File", command=save_to_file)
file_menu.add_separator()
file_menu.add_command(label = "  Display File", command=showFile)
file_menu.add_command(label = "  Clear All", command=clear_All)
file_menu.add_separator()
file_menu.add_command(label = "  Exit", command=root.destroy)

# create process menu

process_menu = tk.Menu(my_menu)
#process_menu['bg'] = 'burlywood1' 
my_menu.add_cascade(label ="          Process        ", menu=process_menu)
process_menu.add_command(label = "  Analyze Project", command=analyze_Project)
process_menu.add_command(label = "  Synthesize Project", command=synthesize_Project)

# create settings menu
settings_menu = tk.Menu(my_menu)
my_menu.add_cascade(label =  "        Settings       ", menu=settings_menu)
settings_menu.add_command(label = "  Save Settings", command=save_settings)
settings_menu.add_separator()
settings_menu.add_checkbutton(label = 'Normalize', onvalue=1, offvalue=0, variable=normalizeVariable, command=normalizeChange)


# create all of the main containers
#center_frame = tk.Frame(root, width=50, height=600)

# layout all of the main containers

entry_frame = tk.Frame(root, width=1, height=1)
entry_frame.pack(side=TOP, padx=10, pady=10)
text_frame = tk.Frame(root, width=100, height=100, padx=10, pady=10, bg='white')
text_frame.pack(fill = BOTH, expand=1, padx=20, pady=20)
text = tk.Text(text_frame, padx = 5, pady = 1, width = 1, height = 1, wrap="word", undo=True, font=("Georgia", "12"))
 
control_label = tk.Label(entry_frame, text='Control File:', width = 8, padx = '8')
control_label.grid(row=0, column=0, sticky=W, pady=2)
cFile_Variable = tk.StringVar()
cFile_label = tk.Label(entry_frame, textvariable=cFile_Variable, width=34, bg='white', height=1, borderwidth=2, relief="sunken", anchor = 'w', padx=2)
cFile_label.grid(row=0, column=1, sticky=W, pady=2)
data_label = tk.Label(entry_frame, text='Data File:', padx = '4')
data_label.grid(row=0, column=2, sticky=W, pady=2)
dFile_Variable = tk.StringVar()
dFile_label = tk.Label(entry_frame, textvariable=dFile_Variable, width=36, bg='white', height=1, borderwidth=2, relief="sunken", anchor = 'w')
dFile_label.grid(row=0, column=3, sticky=W, pady=2)
title_Label = tk.Label(entry_frame, text='Message:', width = 10)
title_Label.grid(row=1, column=0, sticky=W, pady=2)
message_Variable = tk.StringVar()
message_label = tk.Label(entry_frame, width=80, height=1, bg='white', borderwidth=2, relief="sunken", anchor = 'w')
message_label.grid(row=1, column=1, sticky=W, columnspan=3, pady=2)

root.mainloop()
